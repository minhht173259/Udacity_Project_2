Run: npm start

Images: /screenshots

URL beanstalk: 